#pragma once

// Matrix size: 5 Rows, 15 Columns
#define MATRIX_ROWS 5
#define MATRIX_COLS 15

#define DIODE_DIRECTION COL2ROW
#define DEBOUNCE 5