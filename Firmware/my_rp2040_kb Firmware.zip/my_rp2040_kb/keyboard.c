#include "quantum.h"

void keyboard_pre_init_user(void) {
}